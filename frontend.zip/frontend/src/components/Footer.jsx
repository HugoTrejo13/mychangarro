function Footer() {
    return <footer className="footer">{/* Aquí puedes poner tu propio contenido */}</footer>;
  }
  
  export default Footer;
  